#include "ixj0644_Living_Thing.h"


Living_Thing::Living_Thing(string str){
    this->name = name;
}

string Living_Thing::get_name(){
    return this->name;    
}






