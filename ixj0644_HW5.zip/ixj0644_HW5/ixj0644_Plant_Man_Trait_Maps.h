#include "ixj0644_Pea_Plant_Trait_Maps.h"
#include "ixj0644_Human_Trait_Maps.h"

class Plant_Man_Trait_Maps: public Pea_Plant_Trait_Maps, public Human_Trait_Maps {
    public:
        Plant_Man_Trait_Maps(){};

};




